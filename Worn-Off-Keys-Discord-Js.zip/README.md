HOW TO USE CONFIG.JSON:

Create a file called "config.json" within your project folder. It will have this syntax:

```
{
  "token": "bot token here",
  "prefix": "default command prefix here",
  "mongoPath": "mongo path here",
  "redisPath": "redis path here"
}
```

Redis and mongo can be ignored depending on where you are in the series.

If you need help with anything then feel free to ask in the Worn Off Keys Discord server:

http://wornoffkeys.com/discord?from=discord-repo

If you found my content helpful then consider becoming a Patron. You'll receive cool perks and will help support me as a content creator for just a few dollars a month:

http://wornoffkeys.com/patreon?from=discord-repo
